package com.JavaMailApi.JavaMailApiProject;

import java.io.File;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.MongoClient;
import com.mongodb.gridfs.GridFS;
import com.mongodb.gridfs.GridFSDBFile;
import com.mongodb.gridfs.GridFSInputFile;

public class SaveFileApps {

	public static void main(String args[]) {
		String file = "D:/sss/welcome.txt.txt";
		SaveFileApps ob = new SaveFileApps();
		ob.updateDocument(file);

	}

	public void updateDocument(String newfiles) {

		try {

			MongoClient client = new MongoClient("localhost", 27017);
			DB db = client.getDB("newtemp");
			
			// get collection
			DBCollection ncol = db.getCollection("dbdata1.files");

			File f = new File(newfiles);
			String demofile = f.getName();
			// Find and Remove old file  
			DBCursor c = ncol.find(new BasicDBObject("filename", demofile));
			while (c.hasNext()) {
				ncol.remove(c.next());

			}
			// new fiile inpiut
			GridFS gfs1 = new GridFS(db, "dbdata1");
			GridFSInputFile inputFile = gfs1.createFile(f);

			inputFile.setId("20");
			inputFile.setFilename(demofile);
			inputFile.put("title", "abcs");
			inputFile.put("author", "xyzs");
			inputFile.save();
			System.out.println("the file is insertc");
			
			
			// download process
			GridFSDBFile outputfile = gfs1.findOne(new BasicDBObject("filename", demofile));
			String filepath = "c:\\temp\\" + demofile;

			outputfile.writeTo(filepath);
			System.out.println("Document updated");

		}

		catch (Exception e) {
			System.err.println(e);
		}

	}

}
