package nare;

import java.awt.Cursor;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Iterator;

//import org.bson.*;

import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.gridfs.GridFSBucket;
import com.mongodb.client.gridfs.GridFSBuckets;
import org.bson.BSON;
import org.w3c.dom.Document;


public class MongoDbConnection {

	public static void getConnection(String subject2, String fromAdd2, String toAdd2, String date2, String textData,
			String attachmentfile)

	{

		try {
			MongoClient client = new MongoClient("localhost", 27017);
			MongoDatabase database = client.getDatabase("dbdata");
			MongoCollection<Document> collections = database.getCollection("dbdatacol");

			String str = "";
			Document d2 = null;
			Document d = null;
			File filename;
			String demofile = "";
			String file = "";
			InputStream streamToUploadFrom = null;

			boolean isEmpty = attachmentfile == null || attachmentfile.trim().length() == 0;
			if (isEmpty) {
				str = "No Attachment";
				// System.out.println("str " + str);
				d = new Document();
				((Object) d).append("AttachmentData", "No Attach File");

			} else {
				file = attachmentfile;
				str = "AttachmentFile";
				filename = new File(file);
				demofile = filename.getName();

				// System.out.println(" Attach File " + str);
				// SaveFileApp savefile=new SaveFileApp();
				// savefile.saveFile(file);
				streamToUploadFrom = new FileInputStream(new File(file));

				// Create some custom options

				GridFSBucket gridFSBucket1 = GridFSBuckets.create(database, "dbdatadir1");

				d = new Document();
				((Object) d).append("type", "present");

				GridFSUploadOptions options = new GridFSUploadOptions().chunkSizeBytes(1024).metadata(d);

				ObjectId fileId1 = gridFSBucket1.uploadFromStream(demofile, streamToUploadFrom, options);

				String filepath = "c:\\temp\\" + demofile;

				FileOutputStream streamToDownload = new FileOutputStream(filepath);
				GridFSDownloadByNameOptions downloadOptions = new GridFSDownloadByNameOptions().revision(0);
				gridFSBucket1.downloadToStreamByName(demofile, streamToDownload, downloadOptions);
				streamToDownload.close();
			}

			MongoCollection<Document> newcol = database.getCollection("dbdatadir1.files");

			FindIterable<Document> netIte = newcol.find();

			Iterator it = netIte.iterator();

			if (it.hasNext()) {
				d.append("AttachmentFile", it.next());
			}

			Document d11 = new Document();

			d11.append("Subject", subject2);
			d11.append("FromAddress", fromAdd2);
			d11.append("ToAddress", toAdd2);
			d11.append("Date", date2);
			d11.append("BodyText", textData);
			d11.append("AttachmentFile", d);

			collections.insertOne(d11);

			System.out.println("document inserted");
			DB db = client.getDB("dbdata");
			DBCollection col = db.getCollection("dbdatadir1.files");

			Cursor cursor = col.find();
			while (cursor.hasNext()) {

				col.remove(cursor.next());
			}

		} catch (Exception e) {
			System.err.println(e);
		}

	}

	public void updateDocument(String file) {

	}

}
