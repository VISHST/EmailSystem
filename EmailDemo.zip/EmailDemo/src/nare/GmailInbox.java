package com.JavaMailApi.JavaMailApiProject;
 

import java.io.File;
import java.util.Properties;

import javax.mail.Address;
import javax.mail.BodyPart;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.Part;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMultipart;
 
public class GmailInbox
{
 
    public static void main(String[] args) 
    {
 
        GmailInbox gmail = new GmailInbox();
        gmail.read();
 
    }
 
    public void read() 
    {
 
        Properties props = new Properties();
       
        props.put("mail.smtp.host","smtp.gmail.com");
        props.put("mail.smtp.socketFactory.port","465");
        props.put("mail.smtp.socketFactory.class","javax.net.ssl.SSLSocketFactory");
        props.put("mail.smtp.auth","true");
        props.put("mail.smtp.port", "465");
 
        try 
        {
           
        	  Session session = Session.getInstance(props, new javax.mail.Authenticator() {
          	    protected PasswordAuthentication getPasswordAuthentication() {
          	        return new PasswordAuthentication("nagendrakumar.t310@gmail.com", "tatipaka12");
          	    }
          	});
 
            Store store = session.getStore("imaps");
            store.connect("smtp.gmail.com", "nagendrakumar.t310@gmail.com", "tatipaka12");
 
            Folder inbox = store.getFolder("inbox");
            inbox.open(Folder.READ_ONLY);
            int messageCount = inbox.getMessageCount();
 
            System.out.println("Total Messages:- " + messageCount);
 
            Message[] messages = inbox.getMessages();
               
            System.out.println("------------------------------");
            
    
            for (int i = 0; i < messageCount; i++) 
            {
                String textData=null;
                System.out.println("---------------------------------");
                
                System.out.println("Email Number " + (i + 1));
                
                String subject= messages[i].getSubject();
                String fromAdd= messages[i].getFrom()[0].toString();
                String date=  messages[i].getSentDate().toString();
                System.out.println("Subject" + subject);
                System.out.println("FromAdress" + fromAdd);
                System.out.println("Date" + date);
                
                Address[] recipients = messages[i].getRecipients(Message.RecipientType.TO);
                String toAdd=null;
                for (Address address : recipients)
                {
                    toAdd=address.toString();
                    System.out.println("ToAdress" + toAdd);
                }
                String messageContent = "";
            String contentType=messages[i].getContentType();
                
                String attachFiles = "";
                String saveDirectory="E:/Attachment";
                String newfile="";
                if (contentType.contains("multipart")) {
                 
                    Multipart multiPart = (Multipart) messages[i].getContent();
                    int numberOfParts = multiPart.getCount();
                   
                    for (int partCount = 0; partCount < numberOfParts; partCount++)
                    {
                        MimeBodyPart part = (MimeBodyPart) multiPart.getBodyPart(partCount);
                        
                        
                        String fileName = part.getFileName();
                        
                        
                        boolean isEmpty = fileName == null || fileName.trim().length() == 0;
              		  if (isEmpty) {
              			 newfile="";
              		
              		           }
              		  else
              		  {
                        System.out.println("AttchmentFile" + fileName);
                        attachFiles += fileName + ", ";
                        part.saveFile(saveDirectory + File.separator + fileName);
                        newfile=saveDirectory + File.separator + fileName;

                    
              		  }
                       
                        if (Part.ATTACHMENT.equalsIgnoreCase(part.getDisposition())) 
                        {
                            // this part is attachment
                     
                        
                           
                  
                            
                            
                              
                            
                            
                        } else 
                        {
                        	
                      
                        	
                            // this part may be the message content
                            messageContent = part.getContent().toString();
                         
                        }
                    }
                }
               
            
                if (messages[i].isMimeType("text/plain")) 
                {
                    textData = messages[i].getContent().toString();
                    
                   
                } 
                else if (messages[i].isMimeType("multipart/*")) 
                {
                    MimeMultipart mimeMultipart = (MimeMultipart) messages[i].getContent();
                    
                    textData = getTextFromMimeMultipart(mimeMultipart);
                    System.out.println("BodyText" + textData);
                    

                    MongoDbConnection.getConnection(subject,fromAdd,toAdd,date,textData,newfile);
                }
                
               

                
            }


            inbox.close(true);
            store.close();
 
        
        }
        catch (Exception e) 
        {
            e.printStackTrace();
        }
     
    }


	private String getTextFromMimeMultipart(MimeMultipart mimeMultipart) throws Exception {
		 String result = "";
		    int count = mimeMultipart.getCount();
		    for (int i = 0; i < count; i++) 
		    {
		        BodyPart bodyPart = mimeMultipart.getBodyPart(i);
		        if (bodyPart.isMimeType("text/plain")) 
		        {
		            result = result + "\n" + bodyPart.getContent();
		        
		            break;
		        }
		        else if (bodyPart.isMimeType("text/html")) 
		        {
		            String html = (String) bodyPart.getContent();
		            result = result + "\n" + org.jsoup.Jsoup.parse(html).text();
		            
		        } 
		        else if (bodyPart.getContent() instanceof MimeMultipart){
		            result = getTextFromMimeMultipart((MimeMultipart)bodyPart.getContent());
		           
		         
		        }
		      

		    }
		        
		    
		    return result;
	}
 
}