package nare;

import java.io.File;

import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.gridfs.GridFS;
import com.mongodb.gridfs.GridFSInputFile;
import org.bson.util.*;
import org.w3c.dom.Document;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {

			MongoClient client = new MongoClient("localhost", 27017);
			DB database = (DB) client.getDatabase("dbdata");
			DBCollection collections = database.getCollection("dbdatacol");

			String str = "D:/sss/welcome.txt.txt";
			File f = new File(str);
			String demofile = f.getName();

			GridFS gfs1 = new GridFS(database, "dbdata1");
			GridFSInputFile inputFile = gfs1.createFile(f);

			inputFile.setId("20");
			inputFile.setFilename(demofile);
			inputFile.put("title", "abcs");
			inputFile.put("author", "xyzs");
			inputFile.save();
			System.out.println("the file is insertc");

		} catch (Exception e) {
			System.err.println(e);
		}

	}

}
