package emaildemo;

import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.util.Arrays;
import java.util.Date;
import java.util.Properties;

import javax.mail.Address;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.NoSuchProviderException;
import javax.mail.Part;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.search.SearchTerm;

public class bounced {
	static String keyword = "Delivery Status Notification (Failure)";
	static FileOutputStream fout ;
	static BufferedOutputStream bout;

	public static void addresesFind() throws MessagingException, IOException, Exception {

		String host = "smtp.googlemail.com"; // change accordingly
		String username = "ram@sbhstech.com"; // change accordingly
		String password = "reddy123"; // change accordingly

		// create properties field
		Properties properties = new Properties();
		// SSL setting
		properties.setProperty("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
		properties.setProperty("mail.imaps.socketFactory.fallback", "false");
		properties.setProperty("mail.imaps.socketFactory.port", String.valueOf("993"));
		properties.put("mail.imaps.host", host);
		properties.put("mail.imaps.port", "993");
		properties.put("mail.imaps.starttls.enable", "true");
		Session emailSession = Session.getDefaultInstance(properties);
		// create the POP3 store object and connect with the pop server
		Store store = emailSession.getStore("imaps");

		System.out.println("Waiting to connect with emailserver");

		store.connect(host, username, password);

		System.out.println("Connected to emailserver");
		
		// create the folder object and open it
		Folder emailFolder = store.getFolder("INBOX");
		emailFolder.open(Folder.READ_ONLY);

		// Message[] messages = emailFolder.getMessages(messages ,(t1) -> {
		//
		// } );

		// // creates a search criterion
		// SearchTerm searchCondition = new SearchTerm() {
		// @Override
		// public boolean match(Message message) {
		// try {
		//
		// if (message.getSubject().contains(keyword )) {
		// return true;
		// }
		// } catch (MessagingException ex) {
		// ex.printStackTrace();
		// }
		// return false;
		// }
		// };

		// performs search through the folder
		System.out.println("Waiting to get the messages");
		Message[] foundMessages = emailFolder.getMessages();
		System.out.println("Got messages");

//		Arrays.sort(foundMessages, (m1, m2) -> {
//
//			try {
//				return m2.getSentDate().compareTo(m1.getSentDate());
//			} catch (MessagingException e) {
//				throw new RuntimeException(e);
//			}
//		});
		System.out.println("messages.length---" + foundMessages.length);

		for (int i1 = 0; i1 < foundMessages.length; i1++) {
			Message message = foundMessages[i1];
			//System.out.println("---------------------------------");
			//System.out.println("MESSAGE #" + (i1 + 1) + ":");

			Address replyAdd[] = message.getFrom();
			if (replyAdd.length != 0) {
//				if (replyAdd[0].toString().contains("mailer-daemon") || replyAdd[0].toString().contains("postmaster@")) {
				System.out.println("Message Count = "+i1);
			if ((replyAdd[0].toString().contains("mailer-daemon") && message.getSubject().toString().contains("Delivery Status Notification (Failure)"))) {
				
					System.out.println("This is a bounced email");
					writePart(message);
					// Object body = message.getContent();
					// if (body instanceof Part){
					// if (((Part)body).isMimeType("text/plain")){
					// String bodyStr = (String)((Part)body).getContent();
					// System.out.println("bodyStr = "+bodyStr);
					// }
					// }
				}
			}
			

		} // close the store and folder objects
		
		store.close();
		emailFolder.close(false);
		fout.close();
		bout.close();

	}

	public static void writePart(Part p) throws Exception {
		if (p instanceof Message)
			// Call methos writeEnvelope
			writeEnvelope((Message) p);

		// check if the content has attachment
		if (p.isMimeType("multipart/*")) {

			Multipart mp = (Multipart) p.getContent();
			int count = mp.getCount();
			for (int i = 0; i < count; i++)
				writePart(mp.getBodyPart(i));
		}
		// check if the content is a nested message
		else if (p.isMimeType("message/rfc822")) {
			System.out.println("This is a Nested Message");
			System.out.println("---------------------------");
			writePart1((Part) p.getContent());
			
		}

	}

	private static void writePart1(Part p) throws Exception {
		if (p instanceof Message)
		 writeEnvelope((Message) p);
		// Call methos writeEnvelope
		Address[] a;
			
		// TO
		
			if ((a = ((Message) p).getRecipients(Message.RecipientType.TO)) != null && a.length > 0) {
				for (int j = 0; j < a.length; j++) 
					System.out.println(" Invalid sent address : " + a[j].toString());
					String invalidAddresses = a[0].toString();
					if (fout == null){
							fout = new FileOutputStream("final.txt", true);
							bout = new BufferedOutputStream(fout);
					}
					String s = ( invalidAddresses+"\n");
					byte b[] = s.getBytes();
					
					bout.write(b);
					bout.flush();
			}
		}


	public static void writeEnvelope(Message m) throws Exception {
//		System.out.println("This is the message envelope");
//		System.out.println("---------------------------");

		Address[] a;

		// FROM
		if ((a = m.getFrom()) != null) {
			//for (int j = 0; j < a.length; j++)
				//System.out.println("FROM: " + a[j].toString());

		}

		// TO
		if ((a = m.getRecipients(Message.RecipientType.TO)) != null) {
			//for (int j = 0; j < a.length; j++)
				//System.out.println("TO: " + a[j].toString());
		}

		// SUBJECT
		if (m.getSubject() != null);
			//System.out.println("SUBJECT: " + m.getSubject());

	}

}
