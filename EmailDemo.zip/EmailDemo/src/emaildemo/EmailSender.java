package emaildemo;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Properties;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Address;
import javax.mail.BodyPart;
import javax.mail.Flags;
import javax.mail.Flags.Flag;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.Message.RecipientType;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Part;
import javax.mail.SendFailedException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.Transport;
import javax.mail.event.TransportEvent;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.search.FlagTerm;
import javax.mail.search.SearchTerm;
import javax.print.DocFlavor.STRING;

//import org.jsoup.Jsoup;
/**
 *
 * @author sairam
 */
public class EmailSender {

	Properties props;
	Session session;
	MimeMessage mimeMessage;
	String host = "smtp.gmail.com";
	static String from;
	String password;
	long currentTimeMillis;
	Transport transport;
	String cc = "gsk.9100@gmail.com";
	String bcc = "gsk.9100@gmail.com";
	private static DataOutputStream output;
	private static FileOutputStream f2;
	private static InputStream x;
	String newline = System.getProperty("line.separator");

	public EmailSender(String from, String password, String message) throws MessagingException {
		System.out.println((this.currentTimeMillis = System.currentTimeMillis()) + "EmailSender");

		EmailSender.from = from;
		this.password = password;

		props = System.getProperties();
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", host);
		props.put("mail,smtp.user", from);
		props.put("mail.smtp.password", password);
		props.put("mail.smtp.port", 587);
		props.put("mail.smtp.auth", "true");
		//props.put("mail.smtp.sendpartial", "true");
		props.put("mail.smtp.reportsuccess", "true");
		// props.put("mail.smtp.from", bounceAddr);
		session = Session.getInstance(props, null);
		mimeMessage = new MimeMessage(session);
		mimeMessage.setFrom(new InternetAddress(from));
		mimeMessage.setSubject("mail demo ");
		mimeMessage.setText(message);
		//
		transport = session.getTransport("smtp");
		transport.connect(host, from, password);
	}

	
	
	public boolean sendMail(String message, String to) throws SendFailedException, MessagingException,
			FileNotFoundException, ClassNotFoundException, SQLException {
		System.out.println((this.currentTimeMillis = System.currentTimeMillis()) + "sendmail");
		try {
			mimeMessage.setRecipient(RecipientType.TO, new InternetAddress(to));
			// mimeMessage.addRecipients(Message.RecipientType.CC,InternetAddress.parse(cc));
			// mimeMessage.addRecipients(Message.RecipientType.BCC,InternetAddress.parse(bcc));
			transport.sendMessage(mimeMessage, mimeMessage.getAllRecipients());
			return false;
		} catch (MessagingException me) {
			me.printStackTrace();
			Exception ex = me;
			if (ex instanceof SendFailedException) {
				SendFailedException sfe = (SendFailedException) ex;

				Address[] vsa = sfe.getValidSentAddresses();
				Address[] vua = sfe.getValidUnsentAddresses();
				Address[] ia = sfe.getInvalidAddresses();

				if (vsa != null && vsa.length > 0) {
					for (int i = 0; i < vsa.length; i++) {
						String validSentAddresses = vsa[i].toString();
						dbConnect(validSentAddresses, "validsent  addres ", from);
						System.out.println("validsent  addres: /n " + validSentAddresses);
						FileOutputStream fout;
						try {

							fout = new FileOutputStream("GSWvalidSentAddresses.txt");
							BufferedOutputStream bout = new BufferedOutputStream(fout);
							String s = ("valid sent addrtess ." + newline + validSentAddresses);
							byte b[] = s.getBytes();
							bout.write(b);
							bout.close();
							fout.close();
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
				} else if (vua != null && vua.length > 0) {

					for (int i = 0; i < vua.length; i++) {
						String validUnsentAddresses = vua[i].toString();
						dbConnect(validUnsentAddresses, "validUnsentAddresses ", from);
						System.out.println("validunsent  addres ");
						FileOutputStream fout;
						try {
							fout = new FileOutputStream("GSWvalidUnsentAddresses.txt");
							BufferedOutputStream bout = new BufferedOutputStream(fout);
							String s = ("validUnsentAddresses : " + newline + validUnsentAddresses);
							byte b[] = s.getBytes();
							bout.write(b);
							bout.close();
							fout.close();
						} catch (IOException e) {
							e.printStackTrace();
						}

					}
				} else if (ia != null && ia.length > 0) {
					for (int i = 0; i < ia.length; i++) {
						String invalidAddresses = ia[i].toString();
						dbConnect(invalidAddresses, "invalidAddresses ", from);
						System.out.println("invalid addres : " + newline + invalidAddresses);
						FileOutputStream fout;
						try {
							fout = new FileOutputStream("GSWinvalidAddresses.txt");
							BufferedOutputStream bout = new BufferedOutputStream(fout);
							String s = ("invalidAddresses :" + newline + invalidAddresses);
							byte b[] = s.getBytes();
							bout.write(b);
							bout.close();
							fout.close();
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
				} else {
				}
				if (ex instanceof MessagingException)
					ex = ((MessagingException) ex).getNextException();
				else
					ex = null;
			}

		} catch (Exception e) {
			System.out.println("Caught Exception = " + e.getClass().getName() + " Message = " + e.getMessage());
		}
		return false;
	}

	public void dbConnect(String Emailid, String Emailstatus, String from) throws SQLException, ClassNotFoundException {
		EmailSender.from = from;
		// STEP 2: Register JDBC driver
		Class.forName("com.mysql.jdbc.Driver");
		// STEP 3: Open a connection
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/vis", "root", "");
		// STEP 4: Execute a query
		Statement stmt = conn.createStatement();
		String sql = "INSERT INTO `EmailHistory` (`Emailid`, `Sentuser`, `Datesent`, `Emailstatus`) " + "VALUES ('"
				+ Emailid + "', '" + from + "', CURRENT_TIMESTAMP, '" + Emailstatus + "');";
		stmt.executeUpdate(sql);
	}

	public String[] sendMailsFromFile(String filePath)
			throws IOException, MessagingException, ClassNotFoundException, SQLException {
		String strLine = "";
		ArrayList<String> listOfMailids = new ArrayList<>();
		System.out.println((this.currentTimeMillis = System.currentTimeMillis()) + " sendMailsFromFile");

		try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
			while ((strLine = br.readLine()) != null) {
				listOfMailids.add(strLine);
			}
		} catch (FileNotFoundException e) {
			System.err.println((filePath) + "Unable to find the file:");
		} catch (IOException e) {
			System.err.println((filePath) + "Unable to read the file:");
		}
		{
			for (String mailid : listOfMailids) {
				sendMail("Test2", mailid);
				System.out.println("Sent Email : " + mailid);
			}

		}
		return null;
	}

	/**
	 *
	 * @throws javax.mail.MessagingException
	 * @throws java.io.IOException
	 */
	public static void Check() throws MessagingException, IOException, Exception {
		String host = "smtp.googlemail.com"; // change accordingly
		String username = "sairao9100@gmail.com"; // change accordingly
		String password = "sai7207661184"; // change accordingly

		// create properties field
		Properties properties = new Properties();

		properties.put("mail.smtp.host", host);
		properties.put("mail.smtp.port", "993");
		properties.put("mail.smtp.starttls.enable", "true");
		Session emailSession = Session.getDefaultInstance(properties);
		// create the POP3 store object and connect with the pop server
		Store store = emailSession.getStore("imaps");

		store.connect(host, username, password);

		// create the folder object and open it
		Folder emailFolder = store.getFolder("INBOX");
		emailFolder.open(Folder.READ_WRITE);
		// BufferedReader reader = new BufferedReader(new
		// InputStreamReader(System.out));
		// retrieve the messages from the folder in an array and print it

		
		Message[] messages = emailFolder.getMessages();
		
		Arrays.sort(messages, (m1, m2) -> {

			try {
				return m2.getSentDate().compareTo(m1.getSentDate());
			} catch (MessagingException e) {
				throw new RuntimeException(e);
			}
		});
		System.out.println("messages.length---" + messages.length);
		// int i;
		// ArrayList<String> ls = new ArrayList<String>();
		// for (i = 1; i <= 100; i++) {
		// String str = null;
		// str = +i + ":- HOW TO WRITE A CONSOLE OUTPUT IN A TEXT FILE";
		// ls.add(str);
		// }
		// String listString = "";
		// for (String s : ls) {
		// listString += s + "\n";
		// }
		// FileWriter writer = null;
		// try {
		// writer = new FileWriter("final.txt");
		// writer.write(listString);
		// writer.close();
		// } catch (IOException e) {
		// e.printStackTrace();
		// }
		// OUTER:
		for (int i1 = 0; i1 < messages.length; i1++) {
			Message message = messages[i1];
			System.out.println("---------------------------------");
			System.out.println("MESSAGE #" + (i1 + 1) + ":");
			writePart(message);

			// String filePath =
			// "C:/Users/sairam/workspace/EmailDemo/inboxData.txt";
			// java.lang.String attachment = "";

			// store file

			// try {
			// //create a buffered reader that connects to the console, we use
			// it so we can read lines
			// BufferedReader in = new BufferedReader(new
			// OutputStreamWriter(System.out));
			//
			// //read a line from the console
			// String lineFromInput = in.readLine();
			//
			// //create an print writer for writing to a file
			//
			// PrintWriter out = new PrintWriter(new FileWriter(filePath));
			//
			// //output to the file a line
			//
			// out.println("hiiiihii12"+message.getDescription());
			//
			// //close the file (VERY IMPORTANT!)
			// out.close();
			// }
			// catch(IOException e1) {
			// System.out.println("Error during reading/writing");
			// }

			// if ("YES".equals(line)) {
			// message.writeTo(f2);
			// } else if ("QUIT".equals(line)) {
			// break;
			// }
		}

		// close the store and folder objects
		emailFolder.close(false);
		store.close();

	}
	
	
	
	
	/*
	 * This method checks for content-type based on which, it processes and
	 * fetches the content of the message
	 */
	public static void writePart(Part p) throws Exception {
		if (p instanceof Message)
			// Call methos writeEnvelope
			writeEnvelope((Message) p);

		System.out.println("----------------------------");
		System.out.println("CONTENT-TYPE: " + p.getContentType());

		// check if the content is plain text
		if (p.isMimeType("text/plain")) {
			System.out.println("This is plain text");
			System.out.println("---------------------------");
			System.out.println((String) p.getContent());

		}

		// check if the content has attachment
		else if (p.isMimeType("multipart/*")) {
			System.out.println("This is a Multipart");
			System.out.println("---------------------------");
			Multipart mp = (Multipart) p.getContent();
			int count = mp.getCount();
			for (int i = 0; i < count; i++)
				writePart(mp.getBodyPart(i));
		}
		// check if the content is a nested message
		else if (p.isMimeType("message/rfc822")) {
			System.out.println("This is a Nested Message");
			System.out.println("---------------------------");
			writePart((Part) p.getContent());
		}
		// check if the content is an inline image
		else if (p.isMimeType("image/jpeg")) {
			System.out.println("--------> image/jpeg");
			Object o = p.getContent();

			x = (InputStream) o;
			byte[] bArray = new byte[x.available()];

			System.out.println("x.length = " + x.available());
			while (((int) ((InputStream) x).available()) > 0) {
				int result = (int) (((InputStream) x).read(bArray));
				if (result == -1)
					break;
			}
			f2 = new FileOutputStream("/tmp/image.jpg");
			f2.write(bArray);
		} else if (p.getContentType().contains("image/")) {
			System.out.println("content type" + p.getContentType());
			File f = new File("image" + new Date().getTime() + ".jpg");
			output = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(f)));
			com.sun.mail.util.BASE64DecoderStream test = (com.sun.mail.util.BASE64DecoderStream) p.getContent();
			byte[] buffer = new byte[1024];
			int bytesRead;
			while ((bytesRead = test.read(buffer)) != -1) {
				output.write(buffer, 0, bytesRead);
			}
		}

		// Object x = p.getContent();
		// ((Multipart) x).writeTo(new FileOutputStream(new
		// File("C:/Users/sairam/Documents/inboxData.txt")));
		// else {
		// Object o = p.getContent();
		// if (o instanceof String) {
		// System.out.println("This is a string");
		// System.out.println("---------------------------");
		// System.out.println((String) o);
		// } else if (o instanceof InputStream) {
		// System.out.println("This is just an input stream");
		// System.out.println("---------------------------");
		// is = (InputStream) o;
		// is = (InputStream) o;
		// int c;
		// while ((c = is.read()) != -1)
		// System.out.write(c);
		// }
		// else {
		// System.out.println("This is an unknown type");
		// System.out.println("---------------------------");
		// System.out.println(o.toString());
		// }
		// }

	}

	/*
	 * This method would print FROM,TO and SUBJECT of the message
	 */
	public static void writeEnvelope(Message m) throws Exception {
		System.out.println("This is the message envelope");
		System.out.println("---------------------------");

		Address[] a;

		// FROM
		if ((a = m.getAllRecipients()) != null) {
			for (int j = 0; j < a.length; j++)
				System.out.println("FROM: " + a[j].toString());

		}

		// TO
		if ((a = m.getRecipients(Message.RecipientType.TO)) != null) {
			for (int j = 0; j < a.length; j++)
				System.out.println("TO: " + a[j].toString());
		}

		// SUBJECT
		if (m.getSubject() != null)
			System.out.println("SUBJECT: " + m.getSubject());

		// String fileName = "test.txt";
		// File dir = new File("C:/Users/sairam/workspace/EmailDemo");
		// if (!dir.exists()) {
		// dir.mkdirs();
		// }
		// File file = new File(dir, fileName);
		// FileOutputStream fos = new FileOutputStream(file);
		// m.writeTo(fos);
		// fos.close();

	}

};
//
//

//