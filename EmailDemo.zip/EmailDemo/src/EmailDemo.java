
import emaildemo.bounced;

/**
 *
 * @author sairam
 */
public class EmailDemo {

	/**
	 * @param args
	 *            the command line arguments
	 * 
	 */
	public static void main(String[] args) throws Throwable {

		// String filePath = "check.txt";
		// ArrayList<String> listOfMailids = new ArrayList<>();
		// String[] to = new EmailSender(" sairao9100@gmail.com",
		// "sai7207661184", "Test Messsage Body")
		// .sendMailsFromFile(filePath);
		//EmailSender.addresesFind();
		//EmailSender.Check();
		 
		bounced.addresesFind();

		// ReplyToEmail.ReplyToEmail();
	}

}

// Check();
// try {
//
// GmailUtilities gmail = new GmailUtilities();
//
// gmail.connect();
// gmail.openFolder();
//
// int totalMessages = gmail.getMessageCount();
// int newMessages = gmail.getNewMessageCount();
//
// System.out.println("Total messages = " + totalMessages);
// System.out.println("New messages = " + newMessages);
// System.out.println("-------------------------------");
//
// gmail.printAllMessageEnvelopes();
// gmail.printAllMessages();
//
// } catch(Exception e) {
// e.printStackTrace();
// System.exit(-1);
// }
